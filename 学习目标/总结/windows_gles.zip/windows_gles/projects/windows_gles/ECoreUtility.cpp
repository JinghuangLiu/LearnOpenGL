#include "pch.h"
#include "ECoreUtility.h"

void ECoreUtility::stringReplace(std::string& str, char key, char value)
{
	for (char& ch : str)
	{
		if (ch == key)
			ch = value;
	}
}

void ECoreUtility::stringReplace(std::string& str, const char* key, const char* value)
{
	std::string::size_type pos = 0;
	std::string::size_type srclen = strlen(key);
	std::string::size_type dstlen = strlen(value);

	while ((pos = str.find(key, pos)) != std::string::npos)
	{
		str.replace(pos, srclen, value);
		pos += dstlen;
	}
}

void ECoreUtility::stringSplit(const std::string& src, const char* seg, std::vector<std::string>& result, bool ignoreBlank)
{
	std::string::size_type pos = 0;
	std::string::size_type end = 0;
	std::string::size_type seglen = strlen(seg);

	while ((end = src.find(seg, pos)) != std::string::npos)
	{
		if (!ignoreBlank || end - pos > 0)
			result.push_back(src.substr(pos, end - pos));
		pos = end + seglen;
	}

	if (pos <= src.size())
	{
		if (!ignoreBlank || src.size() - pos > 0)
			result.push_back(src.substr(pos, src.size() - pos));
	}
}

std::string ECoreUtility::findPathParent(std::string& path, char separator)
{
	size_t find = path.rfind(separator);
	if (find == std::string::npos || find == 0)
		return "";
	return path.substr(0, find);
}