#include "pch.h"
#include "ECoreEffectRenderDX11.h"
#include "ECoreUtility.h"
#include "stb_image.h"
#include "mmsystem.h"
#pragma comment(lib, "winmm.lib")

#include "DXShader.h"

struct SimpleVertex
{
	XMFLOAT3 Pos;
	XMFLOAT2 Tex;
};

struct CBNeverChanges
{
	XMMATRIX mView;
};

struct CBChangeOnResize
{
	XMMATRIX mProjection;
};

struct CBChangesEveryFrame
{
	XMMATRIX mWorld;
	XMFLOAT4 vMeshColor;
};

static HRESULT CompileShader(const std::string& shaderString, LPCSTR szEntryPoint, LPCSTR szShaderModel, ID3DBlob** ppBlobOut)
{
	DWORD dwShaderFlags = D3DCOMPILE_ENABLE_STRICTNESS;
#ifdef _DEBUG
	// Set the D3DCOMPILE_DEBUG flag to embed debug information in the shaders.
	// Setting this flag improves the shader debugging experience, but still allows 
	// the shaders to be optimized and to run exactly the way they will run in 
	// the release configuration of this program.
	dwShaderFlags |= D3DCOMPILE_DEBUG;

	// Disable optimizations to further improve shader debugging
	dwShaderFlags |= D3DCOMPILE_SKIP_OPTIMIZATION;
#endif

	ID3DBlob* pErrorBlob = nullptr;
	HRESULT hr = D3DCompile(shaderString.c_str(), shaderString.size(), nullptr, nullptr, nullptr, szEntryPoint, szShaderModel, dwShaderFlags, 0, ppBlobOut, &pErrorBlob);
	if (FAILED(hr))
	{
		if (pErrorBlob)
		{
			OutputDebugStringA(reinterpret_cast<const char*>(pErrorBlob->GetBufferPointer()));
			pErrorBlob->Release();
		}
		return hr;
	}
	if (pErrorBlob)
		pErrorBlob->Release();

	return S_OK;
}

ECoreEffectRenderDX11::ECoreEffectRenderDX11()
{

}

ECoreEffectRenderDX11::~ECoreEffectRenderDX11()
{
	//ECoreDestroyFunctions();
}


HRESULT ECoreEffectRenderDX11::init_device(int width, int height)
{
	HRESULT hr = S_OK;

	UINT createDeviceFlags = 0;
#ifdef _DEBUG
	createDeviceFlags |= D3D11_CREATE_DEVICE_DEBUG;
#endif

	D3D_DRIVER_TYPE driverTypes[] =
	{
		D3D_DRIVER_TYPE_HARDWARE,
		D3D_DRIVER_TYPE_WARP,
		D3D_DRIVER_TYPE_REFERENCE,
	};
	UINT numDriverTypes = ARRAYSIZE(driverTypes);

	D3D_FEATURE_LEVEL featureLevels[] =
	{
		D3D_FEATURE_LEVEL_11_1,
		D3D_FEATURE_LEVEL_11_0,
		D3D_FEATURE_LEVEL_10_1,
		D3D_FEATURE_LEVEL_10_0,
	};
	UINT numFeatureLevels = ARRAYSIZE(featureLevels);

	for (UINT driverTypeIndex = 0; driverTypeIndex < numDriverTypes; driverTypeIndex++)
	{
		mDriverType = driverTypes[driverTypeIndex];
		hr = D3D11CreateDevice(nullptr, mDriverType, nullptr, createDeviceFlags, featureLevels, numFeatureLevels, D3D11_SDK_VERSION, &pD3D11Device, &mFeatureLevel, &pD3D11Context);
		if (hr == E_INVALIDARG)
		{
			// DirectX 11.0 platforms will not recognize D3D_FEATURE_LEVEL_11_1 so we need to retry without it
			hr = D3D11CreateDevice(nullptr, mDriverType, nullptr, createDeviceFlags, &featureLevels[1], numFeatureLevels - 1, D3D11_SDK_VERSION, &pD3D11Device, &mFeatureLevel, &pD3D11Context);
		}

		if (SUCCEEDED(hr))
			break;
	}

	if (FAILED(hr))
		return hr;

#ifdef _DEBUG
	hr = pD3D11Device->QueryInterface(__uuidof(ID3D11Debug), reinterpret_cast<void**>(&pD3DDebug));
	if (FAILED(hr))
		return hr;
#endif

	// Obtain DXGI factory from device (since we used nullptr for pAdapter above)
	IDXGIFactory1* dxgiFactory1 = nullptr;
	{
		IDXGIDevice* dxgiDevice = nullptr;
		hr = pD3D11Device->QueryInterface(__uuidof(IDXGIDevice), reinterpret_cast<void**>(&dxgiDevice));
		if (SUCCEEDED(hr))
		{
			IDXGIAdapter* adapter = nullptr;
			hr = dxgiDevice->GetAdapter(&adapter);
			if (SUCCEEDED(hr))
			{
				hr = adapter->GetParent(__uuidof(IDXGIFactory1), reinterpret_cast<void**>(&dxgiFactory1));
				adapter->Release();
			}
			dxgiDevice->Release();
		}
	}
	if (FAILED(hr))
		return hr;

	// Create swap chain
	IDXGIFactory2* dxgiFactory2 = nullptr;
	hr = dxgiFactory1->QueryInterface(__uuidof(IDXGIFactory2), reinterpret_cast<void**>(&dxgiFactory2));
	if (dxgiFactory2)
	{
		// DirectX 11.1 or later
		hr = pD3D11Device->QueryInterface(__uuidof(ID3D11Device1), reinterpret_cast<void**>(&pD3D11Device1));
		if (SUCCEEDED(hr))
		{
			pD3D11Context->QueryInterface(__uuidof(ID3D11DeviceContext1), reinterpret_cast<void**>(&pD3D11Context1));
		}

		DXGI_SWAP_CHAIN_DESC1 sd = {};
		sd.Width = width;
		sd.Height = height;
		sd.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
		sd.SampleDesc.Count = 1;
		sd.SampleDesc.Quality = 0;
		sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
		sd.BufferCount = 1;

		hr = dxgiFactory2->CreateSwapChainForHwnd(pD3D11Device, mRenderWindow, &sd, nullptr, nullptr, &pD3D11SwapChain1);
		if (SUCCEEDED(hr))
		{
			hr = pD3D11SwapChain1->QueryInterface(__uuidof(IDXGISwapChain), reinterpret_cast<void**>(&pD3D11SwapChain));
		}

		dxgiFactory2->Release();
	}

	// Note this tutorial doesn't handle full-screen swapchains so we block the ALT+ENTER shortcut
	dxgiFactory1->MakeWindowAssociation(mRenderWindow, DXGI_MWA_NO_ALT_ENTER);
	dxgiFactory1->Release();

	if (FAILED(hr))
		return hr;


	// Create a render target view
	CComPtr<ID3D11Texture2D> pBackBuffer = nullptr;
	CComPtr<ID3D11Texture2D> pDepthStencil = nullptr;

	hr = pD3D11SwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), reinterpret_cast<void**>(&pBackBuffer));
	if (FAILED(hr))
		return hr;

	hr = pD3D11Device->CreateRenderTargetView(pBackBuffer, nullptr, &pDefaultTargetView);
	if (FAILED(hr))
		return hr;

	// Create depth stencil texture
	D3D11_TEXTURE2D_DESC descDepth = {};
	descDepth.Width = width;
	descDepth.Height = height;
	descDepth.MipLevels = 1;
	descDepth.ArraySize = 1;
	descDepth.Format = DXGI_FORMAT_D24_UNORM_S8_UINT;
	descDepth.SampleDesc.Count = 1;
	descDepth.SampleDesc.Quality = 0;
	descDepth.Usage = D3D11_USAGE_DEFAULT;
	descDepth.BindFlags = D3D11_BIND_DEPTH_STENCIL;
	descDepth.CPUAccessFlags = 0;
	descDepth.MiscFlags = 0;
	hr = pD3D11Device->CreateTexture2D(&descDepth, nullptr, &pDepthStencil);
	if (FAILED(hr))
		return hr;

	// Create the depth stencil view
	D3D11_DEPTH_STENCIL_VIEW_DESC descDSV = {};
	descDSV.Format = descDepth.Format;
	descDSV.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2D;
	descDSV.Texture2D.MipSlice = 0;
	hr = pD3D11Device->CreateDepthStencilView(pDepthStencil, &descDSV, &pDefaultDepthView);
	if (FAILED(hr))
		return hr;

	//Set depth stencil view
	ID3D11RenderTargetView* renderTargetViews[] = { pDefaultTargetView };
	pD3D11Context->OMSetRenderTargets(1, renderTargetViews, pDefaultDepthView);

	init_resource();

	return S_OK;
}

void ECoreEffectRenderDX11::createDrawer()
{

}

void ECoreEffectRenderDX11::destroyDrawer()
{
	onStopPreview();

}

void ECoreEffectRenderDX11::onLoopingStart()
{
	init_device(mRenderWidth, mRenderHeight);
	createDrawer();
}

void ECoreEffectRenderDX11::onLoopingFrame()
{
	mFrameTime += (1.0f / mRenderFps);

	// binding
	ID3D11RenderTargetView* targets[] = { pDefaultTargetView };
	pD3D11Context->OMSetRenderTargets(1, targets, pDefaultDepthView);

	onRendeFrame();

	// present the image
	pD3D11SwapChain->Present(0, 0);
}

void ECoreEffectRenderDX11::onLoopingStop()
{
	destroyDrawer();

	pD3D11Device = NULL;
	pD3D11Context = NULL;
	pD3D11SwapChain = NULL;

	pD3D11Device1 = NULL;
	pD3D11Context1 = NULL;
	pD3D11SwapChain1 = NULL;

	pDefaultTargetView = NULL;
	pDefaultDepthView = NULL;

	if (g_pVertexShader != nullptr)
		g_pVertexShader->Release();
	if (g_pPixelShader != nullptr)
		g_pPixelShader->Release();
	if (g_pVertexLayout != nullptr)
		g_pVertexLayout->Release();
	if (g_pVertexBuffer != nullptr)
		g_pVertexBuffer->Release();
	if (g_pIndexBuffer != nullptr)
		g_pIndexBuffer->Release();
	if (g_pCBNeverChanges != nullptr)
		g_pCBNeverChanges->Release();
	if (g_pCBChangeOnResize != nullptr)
		g_pCBChangeOnResize->Release();

	if (g_pSamplerLinear != nullptr)
		g_pSamplerLinear->Release();
	if (g_pDataTextureResourceView != nullptr)
		g_pDataTextureResourceView->Release();

#if _DEBUG
	OutputDebugString("ReportLiveDeviceObjects >>>>>>>>>>>>>>>>>\r\n");
	pD3DDebug->ReportLiveDeviceObjects(D3D11_RLDO_DETAIL);
	pD3DDebug = NULL;
	OutputDebugString("ReportLiveDeviceObjects <<<<<<<<<<<<<<<<<\r\n");
#endif
}

void ECoreEffectRenderDX11::onStartPreview(const char* videoFile, const char* effectFile)
{
	onStopPreview();
}

void ECoreEffectRenderDX11::onStopPreview()
{

}

void ECoreEffectRenderDX11::onPreviewSizeChange()
{

}

HRESULT ECoreEffectRenderDX11::init_resource()
{
	// Compile the vertex shader
	ID3DBlob* pVSBlob = nullptr;
	HRESULT hr = CompileShader(shader_hlsl_vs, "VS", "vs_4_0", &pVSBlob);
	if (FAILED(hr))
	{
		MessageBox(nullptr, "CompileShader() failed.", "Error", MB_ICONERROR | MB_OK);
		return hr;
	}

	// Create the vertex shader
	hr = pD3D11Device->CreateVertexShader(pVSBlob->GetBufferPointer(), pVSBlob->GetBufferSize(), nullptr, &g_pVertexShader);
	if (FAILED(hr))
	{
		pVSBlob->Release();
		return hr;
	}
	// Define the input layout
	D3D11_INPUT_ELEMENT_DESC layout[] =
	{
		{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0 },
	};
	UINT numElements = ARRAYSIZE(layout);

	// Create the input layout
	hr = pD3D11Device->CreateInputLayout(layout, numElements, pVSBlob->GetBufferPointer(),
		pVSBlob->GetBufferSize(), &g_pVertexLayout);
	pVSBlob->Release();
	if (FAILED(hr))
		return hr;

	// Set the input layout
	pD3D11Context->IASetInputLayout(g_pVertexLayout);

	// Compile the pixel shader
	ID3DBlob* pPSBlob = nullptr;
	hr = CompileShader(shader_hlsl_ps, "PS", "ps_4_0", &pPSBlob);
	if (FAILED(hr))
	{
		MessageBox(nullptr, "CompileShader() failed.", "Error", MB_ICONERROR | MB_OK);
		return hr;
	}

	// Create the pixel shader
	hr = pD3D11Device->CreatePixelShader(pPSBlob->GetBufferPointer(), pPSBlob->GetBufferSize(), nullptr, &g_pPixelShader);
	pPSBlob->Release();
	if (FAILED(hr))
		return hr;

	float imgWidth = 1080;
	float imgHeight = 1920;
	float scaleRate = fminf(1.0f * mRenderWidth / imgWidth, 1.0f * mRenderHeight / imgHeight);
	float xScale = imgWidth * scaleRate*0.5f;
	float yScale = imgHeight * scaleRate*0.5f;
	// Create vertex buffer
	SimpleVertex vertices[] =
	{
		{ XMFLOAT3(-xScale, -yScale, 1.0f), XMFLOAT2(0.0f, 0.0f) },
		{ XMFLOAT3(xScale, -yScale, 1.0f), XMFLOAT2(1.0f, 0.0f) },
		{ XMFLOAT3(xScale, yScale, 1.0f), XMFLOAT2(1.0f, 1.0f) },
		{ XMFLOAT3(-xScale, yScale, 1.0f), XMFLOAT2(0.0f, 1.0f) },
	};

	D3D11_BUFFER_DESC bd = {};
	bd.Usage = D3D11_USAGE_DEFAULT;
	bd.ByteWidth = sizeof(SimpleVertex) * 4;
	bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	bd.CPUAccessFlags = 0;

	D3D11_SUBRESOURCE_DATA InitData = {};
	InitData.pSysMem = vertices;
	hr = pD3D11Device->CreateBuffer(&bd, &InitData, &g_pVertexBuffer);
	if (FAILED(hr))
		return hr;

	// Set vertex buffer
	UINT stride = sizeof(SimpleVertex);
	UINT offset = 0;
	pD3D11Context->IASetVertexBuffers(0, 1, &g_pVertexBuffer, &stride, &offset);

	// Create index buffer
	// Create vertex buffer
	WORD indices[] =
	{
		3,1,0,
		2,1,3
	};

	bd.Usage = D3D11_USAGE_DEFAULT;
	bd.ByteWidth = sizeof(WORD) * 6;
	bd.BindFlags = D3D11_BIND_INDEX_BUFFER;
	bd.CPUAccessFlags = 0;
	InitData.pSysMem = indices;
	hr = pD3D11Device->CreateBuffer(&bd, &InitData, &g_pIndexBuffer);
	if (FAILED(hr))
		return hr;

	// Set index buffer
	pD3D11Context->IASetIndexBuffer(g_pIndexBuffer, DXGI_FORMAT_R16_UINT, 0);

	// Set primitive topology
	pD3D11Context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	// Create the constant buffers
	bd.Usage = D3D11_USAGE_DEFAULT;
	bd.ByteWidth = sizeof(CBNeverChanges);
	bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	bd.CPUAccessFlags = 0;
	hr = pD3D11Device->CreateBuffer(&bd, nullptr, &g_pCBNeverChanges);
	if (FAILED(hr))
		return hr;

	bd.ByteWidth = sizeof(CBChangeOnResize);
	hr = pD3D11Device->CreateBuffer(&bd, nullptr, &g_pCBChangeOnResize);
	if (FAILED(hr))
		return hr;


	// Create the sample state
	D3D11_SAMPLER_DESC sampDesc = {};
	sampDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	sampDesc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
	sampDesc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
	sampDesc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
	sampDesc.ComparisonFunc = D3D11_COMPARISON_NEVER;
	sampDesc.MinLOD = 0;
	sampDesc.MaxLOD = D3D11_FLOAT32_MAX;
	hr = pD3D11Device->CreateSamplerState(&sampDesc, &g_pSamplerLinear);
	if (FAILED(hr))
		return hr;

	// Initialize the world matrices

	// Initialize the view matrix
	XMVECTOR Eye = XMVectorSet(0.0f, 0.0f, -3.0f, 0.0f);
	XMVECTOR At = XMVectorSet(0.0f, 0.0f, 0.0f, 0.0f);
	XMVECTOR Up = XMVectorSet(0.0f, 1.0f, 0.0f, 0.0f);
	g_View = XMMatrixLookAtLH(Eye, At, Up);

	CBNeverChanges cbNeverChanges;
	cbNeverChanges.mView = XMMatrixTranspose(g_View);
	pD3D11Context->UpdateSubresource(g_pCBNeverChanges, 0, nullptr, &cbNeverChanges, 0, 0);

	// Initialize the projection matrix
	//g_Projection = XMMatrixPerspectiveFovLH(XM_PIDIV4, mRenderWidth / (FLOAT)mRenderHeight, 0.01f, 100.0f);
	g_Projection = XMMatrixOrthographicLH(mRenderWidth, mRenderHeight, 0.01f, 100.0f);

	CBChangeOnResize cbChangesOnResize;
	cbChangesOnResize.mProjection = XMMatrixTranspose(g_Projection);
	pD3D11Context->UpdateSubresource(g_pCBChangeOnResize, 0, nullptr, &cbChangesOnResize, 0, 0);
	g_pDataTextureResourceView = (ID3D11ShaderResourceView*)CreateTextureWithRGBAInThread();
	return S_OK;
}
void ECoreEffectRenderDX11::renderPlane(ID3D11ShaderResourceView* textureView)
{
	pD3D11Context->IASetInputLayout(g_pVertexLayout);
	pD3D11Context->IASetIndexBuffer(g_pIndexBuffer, DXGI_FORMAT_R16_UINT, 0);

	// Set vertex buffer
	UINT stride = sizeof(SimpleVertex);
	UINT offset = 0;
	pD3D11Context->IASetVertexBuffers(0, 1, &g_pVertexBuffer, &stride, &offset);


	pD3D11Context->VSSetShader(g_pVertexShader, nullptr, 0);
	pD3D11Context->VSSetConstantBuffers(0, 1, &g_pCBNeverChanges);
	pD3D11Context->VSSetConstantBuffers(1, 1, &g_pCBChangeOnResize);

	pD3D11Context->PSSetShader(g_pPixelShader, nullptr, 0);

	pD3D11Context->PSSetShaderResources(0, 1, &textureView);
	pD3D11Context->PSSetSamplers(0, 1, &g_pSamplerLinear);

	// Set primitive topology
	pD3D11Context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
	pD3D11Context->DrawIndexed(6, 0, 0);
}


void ECoreEffectRenderDX11::onRendeFrame()
{
	D3D11_VIEWPORT viewport;
	viewport.MinDepth = 0.0f;
	viewport.MaxDepth = 1.0f;
	viewport.TopLeftX = 0;
	viewport.TopLeftY = 0;

	// Setup the viewport
	viewport.Width = (FLOAT)mRenderWidth;
	viewport.Height = (FLOAT)mRenderHeight;
	pD3D11Context->RSSetViewports(1, &viewport);

	// Clear color buffer & depth buffer to 1.0 (max depth)
	pD3D11Context->ClearRenderTargetView(pDefaultTargetView, DirectX::Colors::DarkBlue);
	pD3D11Context->ClearDepthStencilView(pDefaultDepthView, D3D11_CLEAR_DEPTH, 1.0f, 0);
}

uint64_t ECoreEffectRenderDX11::CreateTextureWithRGBAInThread()
{
	std::string ecoreRoot = mModulePath;
	for (int idx = 0; idx < 6; idx++)
		ecoreRoot = ECoreUtility::findPathParent(ecoreRoot);

	std::string image = ecoreRoot + "/Resource/ecore-effect-demo/assets/TestImage/image01.png";

	FILE* imageFile = nullptr;
	fopen_s(&imageFile, image.c_str(), "rb");
	if (imageFile == nullptr)
		return 0;

	//you must flip the image when send it into ecore engine.
	stbi_set_flip_vertically_on_load(1);

	int width, height, comp;
	uint8_t* imageData = stbi_load_from_file(imageFile, &width, &height, &comp, 4);
	if (imageData == nullptr)
		return 0;

	CComPtr<ID3D11Texture2D> pRenderTexture = nullptr;
	ID3D11ShaderResourceView* pTextureResourceView = nullptr;

	D3D11_TEXTURE2D_DESC textureDesc;
	HRESULT result;
	D3D11_RENDER_TARGET_VIEW_DESC desc;
	D3D11_SHADER_RESOURCE_VIEW_DESC shaderResourceViewDesc;
	ZeroMemory(&textureDesc, sizeof(textureDesc));

	textureDesc.Width = width;
	textureDesc.Height = height;
	textureDesc.MipLevels = 1;
	textureDesc.ArraySize = 1;
	textureDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	textureDesc.SampleDesc.Count = 1;
	textureDesc.SampleDesc.Quality = 0;
	textureDesc.Usage = D3D11_USAGE_DEFAULT;
	textureDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
	textureDesc.CPUAccessFlags = 0;
	textureDesc.MiscFlags = 0;


	D3D11_SUBRESOURCE_DATA initiaTex{};
	initiaTex.pSysMem = imageData;
	initiaTex.SysMemPitch = sizeof(uint32_t) * width;

	result = pD3D11Device->CreateTexture2D(&textureDesc, &initiaTex, &pRenderTexture);
	if (FAILED(result))
	{
		return 0;
	}

	D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc;
	srvDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
	srvDesc.Texture2D.MipLevels = 1;
	srvDesc.Texture2D.MostDetailedMip = 0;
	result = pD3D11Device->CreateShaderResourceView(pRenderTexture, &srvDesc, &pTextureResourceView);
	if (FAILED(result))
	{
		return 0;
	}

	fclose(imageFile);
	stbi_image_free(imageData);

	return (uint64_t)pTextureResourceView;
}

