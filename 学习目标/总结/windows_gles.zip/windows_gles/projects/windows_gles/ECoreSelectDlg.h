﻿#pragma once


#include "resource.h"

// CECoreSelectDlg 对话框


enum ECoreSelectAPI
{
	ECORE_SELECT_API_DIRECT3D11 = 1,
	ECORE_SELECT_API_OPENGLES30 = 2,
};


class CECoreSelectDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CECoreSelectDlg)

public:
	CECoreSelectDlg(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CECoreSelectDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ECORE_SELECT_API_DIALOG };
#endif

public:
	ECoreSelectAPI getSelectAPI();

protected:
	HICON m_hIcon;

	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持
	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	virtual void OnOK();

	DECLARE_MESSAGE_MAP()

protected:
	ECoreSelectAPI mSelectAPI;
	CButton mSelectDirect3D11;
	CButton mSelectOpenGLES30;
};
