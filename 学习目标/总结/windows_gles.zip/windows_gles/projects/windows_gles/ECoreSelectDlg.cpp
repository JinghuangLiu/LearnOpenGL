﻿// ECoreSelectDlg.cpp: 实现文件
//

#include "pch.h"
#include "ECoreSelectDlg.h"
#include "afxdialogex.h"


// CECoreSelectDlg 对话框

IMPLEMENT_DYNAMIC(CECoreSelectDlg, CDialogEx)

CECoreSelectDlg::CECoreSelectDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_ECORE_SELECT_API_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CECoreSelectDlg::~CECoreSelectDlg()
{
}

void CECoreSelectDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_RADIO_SELECT_DIRECT3D11, mSelectDirect3D11);
	DDX_Control(pDX, IDC_RADIO_SELECT_OPENGLES30, mSelectOpenGLES30);
}

BOOL CECoreSelectDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	mSelectDirect3D11.SetCheck(TRUE);
	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

ECoreSelectAPI CECoreSelectDlg::getSelectAPI()
{
	return mSelectAPI;
}


BEGIN_MESSAGE_MAP(CECoreSelectDlg, CDialogEx)
END_MESSAGE_MAP()


// CECoreSelectDlg 消息处理程序
void CECoreSelectDlg::OnOK()
{
	if (mSelectDirect3D11.GetCheck())
		mSelectAPI = ECoreSelectAPI::ECORE_SELECT_API_DIRECT3D11;
	else
		mSelectAPI = ECoreSelectAPI::ECORE_SELECT_API_OPENGLES30;

	CDialogEx::OnOK();
}
