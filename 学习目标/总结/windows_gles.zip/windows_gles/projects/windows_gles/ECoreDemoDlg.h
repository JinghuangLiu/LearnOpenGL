﻿
// ECoreDemoDlg.h: 头文件
//

#pragma once


#include "ECoreSelectDlg.h"
#include "ECoreEffectRender.h"

#include <string>
#include <vector>
#include <algorithm>

struct EffectItemData
{
	std::string name;
	std::string config;
};

// CECoreDemoDlg 对话框
class CECoreDemoDlg : public CDialogEx
{
// 构造
public:
	CECoreDemoDlg(ECoreSelectAPI apiType, CWnd* pParent = nullptr);	// 标准构造函数

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum {
		IDD = IDD_ECORE_EFFECT_DEMO_DIALOG
	};
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
protected:
	HICON m_hIcon;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

protected:
	ECoreSelectAPI mSelectAPI;
	CStatic mStaticVideoFile;
	CEdit mEditVideoFile;
	CButton mButtonVideoFile;
	CListBox mListEffectList;
	CStatic mEffectPreview;
	CStatic mStaticResolution;
	CButton mButtonPreview;
	CButton mButtonUnload;
	CButton mButtonReload;
	
	std::string mEffectCoreRoot;
	std::vector<EffectItemData> mEffectDatas;
	ECoreEffectRender* mEffectRenderer = nullptr;

protected:
	afx_msg void OnClose();
	afx_msg void OnSize(UINT nType, int cx, int cy);

protected:
	void OnInitPath();
	void OnInitData();
	void OnSizeChange();

protected:
	void loadRenderer();
	void unloadRenderer();
	
public:
	afx_msg void OnLbnDblclkListEffectList();
	afx_msg void OnBnClickedButtonPreview();
	afx_msg void OnBnClickedButtonUnloadEngine();
	afx_msg void OnBnClickedButtonReloadEngine();
	
};
