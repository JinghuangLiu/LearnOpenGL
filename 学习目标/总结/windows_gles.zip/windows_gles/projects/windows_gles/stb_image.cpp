
#include "pch.h"

/////////////image loader
#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_PNG
//#define STBI_ONLY_TGA
//#define STBI_ONLY_BMP
#define STBI_ONLY_JPEG
#include "stb_image.h"