//
// Created by wakeyang on 2018/5/9.
//
#include "pch.h"
#include "XSDrawerTEX.h"

#include "xsprite_draw_texture_vert.glsl"
#include "xsprite_draw_texture_frag.glsl"

namespace xscore
{
    XSDrawerTEX::XSDrawerTEX()
    {
        memset(mVtxBuf, 0, sizeof(mVtxBuf));
        memset(mTxtBuf, 0, sizeof(mTxtBuf));
        mInverse = false;
        mDrawMode = XSDRAW_MODE_TWIST;
    }

    XSDrawerTEX::~XSDrawerTEX()
    {
        mProgram.reset();
    }


    void XSDrawerTEX::open(XSSize scnSize, XSSize imgSize, int imgDegree, bool inverse, XSDrawMode drawMode)
    {
        mProgram.reset(new XSProgram(xsprite_draw_texture_vert, xsprite_draw_texture_frag));

        const float* vertexArray = XSUtils::getVertexBufferSix();

        memcpy(mVtxBuf, vertexArray, sizeof(mVtxBuf));

        const float* textureArray = XSUtils::getTexcoodBufferSix();

        memcpy(mTxtBuf, textureArray, sizeof(mTxtBuf));

        update(scnSize, imgSize, imgDegree, inverse, drawMode);
    }

    void XSDrawerTEX::update(XSSize scnSize, XSSize imgSize, int imgDegree, bool inverse, XSDrawMode drawMode)
    {
        mScnSize = scnSize;
        mImgSize = imgSize;
        mInverse = inverse;
        mDrawMode = drawMode;

        mMatrix.makeIdentity();
        if (mInverse)
        {
            mMatrix.makeOrtho2D(-mScnSize.width / 2, mScnSize.width / 2, -mScnSize.height / 2, mScnSize.height / 2, -1, 10);
            mMatrix.applyScaleRight(1, -1, 1);
        }
        else
        {
            mMatrix.makeOrtho2D(-mScnSize.width / 2, mScnSize.width / 2, -mScnSize.height / 2, mScnSize.height / 2, -1, 10);
        }

        float imgWidth = mImgSize.width;
        float imgHeight = mImgSize.height;

        if (imgDegree == 90 || imgDegree == 270)
            std::swap(imgWidth, imgHeight);

        if (mDrawMode == XSDRAW_MODE_TWIST)
        {
            mMatrix.applyScaleRight(1.0f * mScnSize.width / imgWidth, 1.0f * mScnSize.height / imgHeight, 1);
        }
        else if (mDrawMode == XSDRAW_MODE_INNER)
        {
            float scaleRate = fminf(1.0f * mScnSize.width / imgWidth, 1.0f * mScnSize.height / imgHeight);
            mMatrix.applyScaleRight(scaleRate, scaleRate, 1);
        }
        else if (mDrawMode == XSDRAW_MODE_OUTER)
        {
            float scaleRate = fmaxf(1.0f * mScnSize.width / imgWidth, 1.0f * mScnSize.height / imgHeight);
            mMatrix.applyScaleRight(scaleRate, scaleRate, 1);
        }

        mMatrix.applyScaleRight(imgWidth, imgHeight, 1);
        mMatrix.applyRotateZRight(-1.0f * imgDegree / 180 * M_PI);
    }

    void XSDrawerTEX::draw(int texture)
    {
        mProgram->useProgram();

        int uProject = mProgram->getUniformLocation("u_Project");
        glUniformMatrix4fv(uProject, 1, false, mMatrix.m);

        int posAttrib = mProgram->getAttributeLocation("a_Position");
        int txtAttrib = mProgram->getAttributeLocation("a_texCoord");

        glEnableVertexAttribArray(posAttrib);
        glEnableVertexAttribArray(txtAttrib);

        glVertexAttribPointer(posAttrib, 3, GL_FLOAT, false, 0, mVtxBuf);
        glVertexAttribPointer(txtAttrib, 2, GL_FLOAT, false, 0, mTxtBuf);

        int imgAttrib = mProgram->getUniformLocation("SamplerRGBA");
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, texture);
        glUniform1i(imgAttrib, 0);

        glDrawArrays(GL_TRIANGLES, 0, 6);
    }

    void XSDrawerTEX::close()
    {
        mProgram.reset();
        memset(mVtxBuf, 0, sizeof(mVtxBuf));
        memset(mTxtBuf, 0, sizeof(mTxtBuf));
        mInverse = false;
        mDrawMode = XSDRAW_MODE_TWIST;
    }
}