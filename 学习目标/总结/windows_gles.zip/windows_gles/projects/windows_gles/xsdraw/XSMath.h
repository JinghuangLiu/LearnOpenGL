//
// Created by wakeyang on 2018/4/12.
//

#ifndef XSPRITE_XSMATH_H
#define XSPRITE_XSMATH_H

#include "XSVector2.h"
#include "XSVector3.h"
#include "XSVector4.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846  /* pi */
#endif

namespace xscore
{
    struct XSSize
    {
        float width = 0.0f;
        float height = 0.0f;
    };

    inline XSSize XSSizeMake(float width, float height)
    {
        XSSize size;
        size.width = width;
        size.height = height;
        return size;
    }

    struct XSRange
    {
        float start = 0.0f;
        float duration = -1.0f;

        inline float end()
        {
            return start + duration;
        }
    };

    inline XSRange XSRangeMake(float start, float duration)
    {
        XSRange range;
        range.start = start;
        range.duration = duration;
        return range;
    }


    struct XSEdge
    {
        float top = 0.0f;
        float left = 0.0f;
        float bottom = 0.0f;
        float right = 0.0f;
    };

    struct XSPixel
    {
        uint8_t r = 0;
        uint8_t g = 0;
        uint8_t b = 0;
        uint8_t a = 0;
    };

    inline XSPixel XSPixelFromVector(XSVector4& color)
    {
        XSPixel pixel;
        pixel.r = (uint8_t)(0xFF * color.x);
        pixel.g = (uint8_t)(0xFF * color.y);
        pixel.b = (uint8_t)(0xFF * color.z);
        pixel.a = (uint8_t)(0xFF * color.w);
        return pixel;
    }

    inline int64_t factorial(int64_t n)
    {
        int64_t value = 1;
        for (int64_t idx = 2; idx <= n; idx++)
        {
            value *= idx;
        }
        return value;
    }

    inline int64_t combinations(int64_t m, int64_t n) //select n in m.
    {
        return factorial(m) / (factorial(n) * factorial(m - n));
    }
};

#endif //XSPRITE_XSMATH_H
