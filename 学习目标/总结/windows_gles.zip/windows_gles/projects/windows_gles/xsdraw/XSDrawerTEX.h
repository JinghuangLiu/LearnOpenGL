//
// Created by wakeyang on 2018/5/9.
//

#ifndef XSPRITE_XSDRAWERTEX_H
#define XSPRITE_XSDRAWERTEX_H

#include "XSDrawer.h"
#include "XSProgram.h"

namespace xscore
{
    class XSDrawerTEX : public XSDrawer
    {
    protected:
        XSProgramPtr mProgram;
        XSSize mScnSize;
        XSSize mImgSize;
        bool mInverse;
        XSDrawMode mDrawMode;
        float mVtxBuf[18];
        float mTxtBuf[12];
        XSMatrix mMatrix;

    public:
        XSDrawerTEX();

        virtual ~XSDrawerTEX();

    public:
        virtual void open(XSSize scnSize, XSSize imgSize, int imgDegree, bool inverse, XSDrawMode drawMode);

        virtual void update(XSSize scnSize, XSSize imgSize, int imgDegree, bool inverse, XSDrawMode drawMode);

        virtual void draw(int texture);

        virtual void close();
    };
}


#endif //XSPRITE_XSDRAWERTEX_H
