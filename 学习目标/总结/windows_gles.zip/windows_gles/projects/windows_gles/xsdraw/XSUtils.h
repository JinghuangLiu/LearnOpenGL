//
// Created by wakeyang on 2018/3/26.
//

#ifndef XSPRITE_XSUTILS_H
#define XSPRITE_XSUTILS_H

#include "XSVector2.h"
#include "XSVector3.h"
#include "XSVector4.h"

namespace xscore
{
    class XSUtils
    {
    public:
        static int getRandomInRange(int start, int end);

        static float getRandomInRange(float start, float end);

        static XSVector2 getRandomInRange(const XSVector2& start, const XSVector2& end);

        static XSVector3 getRandomInRange(const XSVector3& start, const XSVector3& end);

        static XSVector4 getRandomInRange(const XSVector4& start, const XSVector4& end);

        static GLuint buildShader(const char* shader, GLint length, GLenum type);

        static GLuint buildProgram(const char* vertexShader, GLint vertexLength, const char* fragmentShader, GLint fragmentLength);

        static const float* getVertexBufferSix();

        static const float* getTexcoodBufferSix();
    };
}

#endif //XSPRITE_XSUTILS_H
