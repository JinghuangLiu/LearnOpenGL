//
// Created by wakeyang on 2018/2/24.
//
#include "pch.h"
#include "XSProgram.h"

#include "XSUtils.h"

namespace xscore
{
    XSProgram::XSProgram(const char* vertexShader, const char* fragmentShader)
    {
        mProgramID = 0;

        mVertexShader = vertexShader;
        mFragmentShader = fragmentShader;

        mProgramID = XSUtils::buildProgram(mVertexShader.c_str(), (GLint)mVertexShader.length(), mFragmentShader.c_str(), (GLint)mFragmentShader.length());
    }

    XSProgram::~XSProgram()
    {
        if (mProgramID != 0)
        {
            glDeleteProgram(mProgramID);
            mProgramID = 0;
        }
    }

    void XSProgram::useProgram()
    {
        if (mProgramID == 0)
        {
            printf("invalid program id !!!");
            return;
        }

        glUseProgram(mProgramID);
    }

    void XSProgram::loseProgram()
    {
        glUseProgram(0);
    }

    GLint XSProgram::getAttributeLocation(const char* name)
    {
        if (mProgramID == 0)
            return -1;

        std::string key = name;
        std::map<std::string, GLuint>::iterator it = mAttrbteLocations.find(key);
        if (it != mAttrbteLocations.end())
        {
            return it->second;
        }
        GLint location = glGetAttribLocation(mProgramID, name);
        if (location >= 0)
        {
            mAttrbteLocations[key] = location;
        }
        return location;
    }

    GLint XSProgram::getUniformLocation(const char* name)
    {
        if (mProgramID == 0)
            return -1;

        std::string key = name;
        std::map<std::string, GLuint>::iterator it = mUniformLocations.find(key);
        if (it != mUniformLocations.end())
        {
            return it->second;
        }
        GLint location = glGetUniformLocation(mProgramID, name);
        if (location >= 0)
        {
            mUniformLocations[key] = location;
        }
        return location;
    }

    GLint XSProgram::getUniformBlockIndex(const char* name)
    {
        if (mProgramID == 0)
            return -1;

        std::string key = name;
        std::map<std::string, GLuint>::iterator it = mUniformBlockIndexes.find(key);
        if (it != mUniformBlockIndexes.end())
        {
            return it->second;
        }
        GLint index = glGetUniformBlockIndex(mProgramID, name);
        if (index >= 0)
        {
            mUniformBlockIndexes[key] = index;
        }
        return index;
    }

    void XSProgram::setUniformBlockBinding(GLuint index, GLuint binding)
    {
        if (mProgramID == 0)
            return;

        glUniformBlockBinding(mProgramID, index, binding);
    }
}

