//
// Created by wakeyang on 2018/2/24.
//

#ifndef XSPRITE_XSPROGRAM_H
#define XSPRITE_XSPROGRAM_H


namespace xscore
{
    class XSProgram;

    typedef std::shared_ptr<XSProgram> XSProgramPtr;
    typedef std::deque<XSProgramPtr> XSProgramPtrList;

    class XSProgram
    {
    protected:
        GLuint mProgramID;
        std::string mVertexShader;
        std::string mFragmentShader;
        std::map<std::string, GLuint> mAttrbteLocations;
        std::map<std::string, GLuint> mUniformLocations;
        std::map<std::string, GLuint> mUniformBlockIndexes;

    public:
        XSProgram(const char* vertexShader, const char* fragmentShader);

        virtual ~XSProgram();

    public:
        void useProgram();

        void loseProgram();

        GLint getAttributeLocation(const char* name);

        GLint getUniformLocation(const char* name);

        GLint getUniformBlockIndex(const char* name);

        void setUniformBlockBinding(GLuint index, GLuint binding);
    };
}

#endif //XSPRITE_XSPROGRAM_H
