//
// Created by wakeyang on 2018/3/1.
//

#ifndef XSPRITE_XSDRAWER_H
#define XSPRITE_XSDRAWER_H

#include "XSUtils.h"
#include "XSMath.h"
#include "XSVector2.h"
#include "XSMatrix.h"

namespace xscore
{
	enum XSDrawMode
	{
		XSDRAW_MODE_TWIST = 1,//����
		XSDRAW_MODE_OUTER = 2,//���Ե
		XSDRAW_MODE_INNER = 3 //�ڱ�Ե
	};

    class XSDrawer;

    typedef std::shared_ptr<XSDrawer> XSDrawerPtr;

    class XSDrawer
    {
    public:
        virtual ~XSDrawer();

    public:
        virtual void open(XSSize scnSize, XSSize imgSize, int imgDegree, bool inverse, XSDrawMode drawMode) = 0;

        virtual void update(XSSize scnSize, XSSize imgSize, int imgDegree, bool inverse, XSDrawMode drawMode) = 0;

        virtual void draw(int texture) = 0;

        virtual void close() = 0;
    };
}

#endif //XSPRITE_XSDRAWER_H
