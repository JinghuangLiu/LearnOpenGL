//
// Created by wakeyang on 2018/2/24.
//
#include "pch.h"
#include "XSCanvasDepth.h"

namespace xscore
{
    XSCanvasDepth::XSCanvasDepth(int width, int height)
    {
        mWidth = width;
        mHeight = height;

        //get old frame buffer
        glGetIntegerv(GL_FRAMEBUFFER_BINDING, (GLint*)&mOFrameBuffer);

        //new texture for render, frame buffer
        glGenTextures(1, &mTextureHolder);

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, mTextureHolder);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT32F, mWidth, mHeight, 0, GL_DEPTH_COMPONENT, GL_FLOAT, nullptr);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

        //new render, frame buffer
        glGenFramebuffers(1, &mTFrameBuffer);
        glBindFramebuffer(GL_FRAMEBUFFER, mTFrameBuffer);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, mTextureHolder, 0);

        if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
            printf("frame buffer bind to texture failure!!!");

        glBindFramebuffer(GL_FRAMEBUFFER, mOFrameBuffer);
    }

    XSCanvasDepth::~XSCanvasDepth()
    {
		glDeleteFramebuffers(1, &mTFrameBuffer);
        glDeleteTextures(1, &mTextureHolder);

        mWidth = 0;
        mHeight = 0;
    }

    void XSCanvasDepth::begin()
    {
        glGetIntegerv(GL_FRAMEBUFFER_BINDING, (GLint*)&mOFrameBuffer);
        glBindFramebuffer(GL_FRAMEBUFFER, mTFrameBuffer);
    }

    void XSCanvasDepth::end()
    {
        glFlush();

        glBindFramebuffer(GL_FRAMEBUFFER, mOFrameBuffer);
    }

    void XSCanvasDepth::resize(int width, int height)
    {
        mWidth = width;
        mHeight = height;

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, mTextureHolder);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT32F, mWidth, mHeight, 0, GL_DEPTH_COMPONENT, GL_FLOAT, nullptr);
    }

    int XSCanvasDepth::getTexture()
    {
        return mTextureHolder;
    }

    int XSCanvasDepth::getWidth()
    {
        return mWidth;
    }

    int XSCanvasDepth::getHeight()
    {
        return mHeight;
    }
}