//
// Created by wakeyang on 2018/2/24.
//

#ifndef XSPRITE_XSCANVASCOLOR_H
#define XSPRITE_XSCANVASCOLOR_H


namespace xscore
{
    class XSCanvasColor;

    typedef std::shared_ptr<XSCanvasColor> XSCanvasColorPtr;

    class XSCanvasColor
    {
    protected:
        int mWidth = 0;
        int mHeight = 0;

        int mOutputs = 0;

        GLuint* mTextureHolder = nullptr;

        GLuint mOFrameBuffer;
        GLuint mTFrameBuffer;
        GLuint mDepthBuffer;

    public:
        XSCanvasColor(int width, int height, int outputs);

        virtual ~XSCanvasColor();

    public:
        void begin();

        void end();

        void resize(int width, int height);

        int getCount();

        int getTexture(int index);

        int getWidth();

        int getHeight();
    };
}

#endif //XSPRITE_XSCANVASCOLOR_H
