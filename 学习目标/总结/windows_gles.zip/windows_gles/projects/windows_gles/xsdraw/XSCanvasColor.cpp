//
// Created by wakeyang on 2018/2/24.
//
#include "pch.h"
#include "XSCanvasColor.h"

namespace xscore
{
    XSCanvasColor::XSCanvasColor(int width, int height, int outputs)
    {
        mWidth = width;
        mHeight = height;

        mOutputs = outputs;

        //get old frame buffer
        glGetIntegerv(GL_FRAMEBUFFER_BINDING, (GLint*)&mOFrameBuffer);

        //new texture for render, frame buffer
        mTextureHolder = new GLuint[mOutputs];
        glGenTextures(mOutputs, mTextureHolder);

        glActiveTexture(GL_TEXTURE0);
        for (int idx = 0; idx < mOutputs; idx++)
        {
            glBindTexture(GL_TEXTURE_2D, mTextureHolder[idx]);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, mWidth, mHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        }

        //new render buffer,
        glGenRenderbuffers(1, &mDepthBuffer);
        glBindRenderbuffer(GL_RENDERBUFFER, mDepthBuffer);
        glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT32F, mWidth, mHeight);

        //new render, frame buffer
        glGenFramebuffers(1, &mTFrameBuffer);
        glBindFramebuffer(GL_FRAMEBUFFER, mTFrameBuffer);
        for (int idx = 0; idx < mOutputs; idx++)
            glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0 + idx, GL_TEXTURE_2D, mTextureHolder[idx], 0);
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, mDepthBuffer);

        //set the frame buffer output mapping relationship, it is just associated with this FBO
        //all devices support at least 8 color attachments.
        GLenum buffers[8] = {
                GL_COLOR_ATTACHMENT0,
                GL_COLOR_ATTACHMENT1,
                GL_COLOR_ATTACHMENT2,
                GL_COLOR_ATTACHMENT3,
                GL_COLOR_ATTACHMENT4,
                GL_COLOR_ATTACHMENT5,
                GL_COLOR_ATTACHMENT6,
                GL_COLOR_ATTACHMENT7
        };
        glDrawBuffers(mOutputs, buffers);

        if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
            printf("frame buffer bind to texture failure!!!");

        glBindFramebuffer(GL_FRAMEBUFFER, mOFrameBuffer);
        glBindRenderbuffer(GL_RENDERBUFFER, 0);
    }

    XSCanvasColor::~XSCanvasColor()
    {
        glDeleteFramebuffers(1, &mTFrameBuffer);
        glDeleteRenderbuffers(1, &mDepthBuffer);

        glDeleteTextures(mOutputs, mTextureHolder);
        delete[] mTextureHolder;

        mWidth = 0;
        mHeight = 0;
    }

    void XSCanvasColor::begin()
    {
        glGetIntegerv(GL_FRAMEBUFFER_BINDING, (GLint*)&mOFrameBuffer);
        glBindFramebuffer(GL_FRAMEBUFFER, mTFrameBuffer);
    }

    void XSCanvasColor::end()
    {
        glFlush();

        glBindFramebuffer(GL_FRAMEBUFFER, mOFrameBuffer);
    }

    void XSCanvasColor::resize(int width, int height)
    {
        mWidth = width;
        mHeight = height;

        glActiveTexture(GL_TEXTURE0);
        for (int idx = 0; idx < mOutputs; idx++)
        {
            glBindTexture(GL_TEXTURE_2D, mTextureHolder[idx]);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, mWidth, mHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
        }

        glBindRenderbuffer(GL_RENDERBUFFER, mDepthBuffer);
        glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT32F, mWidth, mHeight);
        glBindRenderbuffer(GL_RENDERBUFFER, 0);
    }

    int XSCanvasColor::getCount()
    {
        return mOutputs;
    }

    int XSCanvasColor::getTexture(int index)
    {
        return mTextureHolder[index];
    }

    int XSCanvasColor::getWidth()
    {
        return mWidth;
    }

    int XSCanvasColor::getHeight()
    {
        return mHeight;
    }
}