//
// Created by wakeyang on 2018/2/24.
//

#ifndef XSPRITE_XSCANVASDEPTH_H
#define XSPRITE_XSCANVASDEPTH_H

namespace xscore
{
    class XSCanvasDepth;

    typedef std::shared_ptr<XSCanvasDepth> XSCanvasDepthPtr;

    class XSCanvasDepth
    {
    protected:
        int mWidth = 0;
        int mHeight = 0;

        GLuint mTextureHolder;

        GLuint mOFrameBuffer;
        GLuint mTFrameBuffer;

    public:
        XSCanvasDepth(int width, int height);

        virtual ~XSCanvasDepth();

    public:
        void begin();

        void end();

        void resize(int width, int height);

        int getTexture();

        int getWidth();

        int getHeight();
    };
}

#endif //XSPRITE_XSCANVASDEPTH_H
