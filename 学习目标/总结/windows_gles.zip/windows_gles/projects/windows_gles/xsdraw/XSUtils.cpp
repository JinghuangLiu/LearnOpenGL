//
// Created by wakeyang on 2018/3/26.
//
#include "pch.h"
#include "stdio.h"
#include "XSUtils.h"



namespace xscore
{
    int XSUtils::getRandomInRange(int start, int end)
    {
        int count = end - start + 1;
        int offset = rand() % count;
        return start + offset;
    }

    float XSUtils::getRandomInRange(float start, float end)
    {
        float ranv = 1.0f * (rand() % 10000) / 10000;
        return start + (end - start) * ranv;
    }

    XSVector2 XSUtils::getRandomInRange(const XSVector2& start, const XSVector2& end)
    {
        float ranv = 1.0f * (rand() % 10000) / 10000;
        return start + (end - start) * ranv;
    }

    XSVector3 XSUtils::getRandomInRange(const XSVector3& start, const XSVector3& end)
    {
        float ranv = 1.0f * (rand() % 10000) / 10000;
        return start + (end - start) * ranv;
    }

    XSVector4 XSUtils::getRandomInRange(const XSVector4& start, const XSVector4& end)
    {
        float ranv = 1.0f * (rand() % 10000) / 10000;
        return start + (end - start) * ranv;
    }

    GLuint XSUtils::buildShader(const char* shader, GLint length, GLenum type)
    {
        GLuint shaderHandle = glCreateShader(type);
        if (shaderHandle > 0)
        {
            glShaderSource(shaderHandle, 1, &shader, &length);
            glCompileShader(shaderHandle);

            GLint compiled = 0;
            glGetShaderiv(shaderHandle, GL_COMPILE_STATUS, &compiled);

            if (compiled == 0)
            {
                char buf[512] = {0};
                GLsizei len = 0;
                glGetShaderInfoLog(shaderHandle, 512, &len, buf);
                buf[len] = 0;
                printf("build shader error: %s", buf);
                return 0;
            }
        }
        return shaderHandle;
    }

    GLuint XSUtils::buildProgram(const char* vertexShader, GLint vertexLength, const char* fragmentShader, GLint fragmentLength)
    {
        GLuint vertexHandle = buildShader(vertexShader, vertexLength, GL_VERTEX_SHADER);
        GLuint fragmentHandle = buildShader(fragmentShader, fragmentLength, GL_FRAGMENT_SHADER);

        GLuint programHandle = glCreateProgram();
        if (programHandle > 0)
        {
            glAttachShader(programHandle, vertexHandle);
            glAttachShader(programHandle, fragmentHandle);
            glLinkProgram(programHandle);

            GLint linkStatus = 0;
            glGetProgramiv(programHandle, GL_LINK_STATUS, &linkStatus);
            if (linkStatus == 0)
            {
                char buf[512] = {0};
                GLsizei len = 0;
                glGetProgramInfoLog(programHandle, 512, &len, buf);
                buf[len] = 0;
                printf("build program error: %s", buf);
                glDeleteProgram(programHandle);
                programHandle = 0;
            }
            glDeleteShader(vertexHandle);
            glDeleteShader(fragmentHandle);
        }
        return programHandle;
    }

    const float* XSUtils::getVertexBufferSix()
    {
        static float vertexArray[18] = {-1.0f / 2, 1.0f / 2, -1,
                                        -1.0f / 2, -1.0f / 2, -1,
                                        1.0f / 2, -1.0f / 2, -1,
                                        -1.0f / 2, 1.0f / 2, -1,
                                        1.0f / 2, -1.0f / 2, -1,
                                        1.0f / 2, 1.0f / 2, -1};
        return vertexArray;
    }

    const float* XSUtils::getTexcoodBufferSix()
    {
        static float textureArray[12] = {0, 0,
                                         0, 1,
                                         1, 1,
                                         0, 0,
                                         1, 1,
                                         1, 0};
        return textureArray;
    }
}