//
// Created by wakeyang on 2018/3/1.
//
#include "pch.h"
#include "XSDrawer.h"

namespace xscore
{
	XSDrawer::~XSDrawer()
	{

	}
}