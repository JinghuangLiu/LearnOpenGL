#pragma once

#include <string>
#include <vector>
#include <algorithm>

class ECoreUtility
{
public:
	static void stringReplace(std::string& str, char key, char value);
	static void stringReplace(std::string& str, const char* key, const char* value);
	static void stringSplit(const std::string& src, const char* seg, std::vector<std::string>& result, bool ignoreBlank);
	static std::string findPathParent(std::string& path, char separator = '/');
};

