#include "pch.h"
#include "ECoreEffectRender.h"

#include "mmsystem.h"
#pragma comment(lib, "winmm.lib")

ECoreEffectRender::ECoreEffectRender()
{
	InitializeCriticalSection(&mAsyncFuncLock);
}

ECoreEffectRender::~ECoreEffectRender()
{
	DeleteCriticalSection(&mAsyncFuncLock);
}

void ECoreEffectRender::createRenderer(const char* builtin, HWND wind)
{
	mBuiltinPath = builtin;
	mRenderWindow = wind;

	RECT client;
	::GetClientRect(mRenderWindow, &client);

	mRenderWidth = client.right - client.left;
	mRenderHeight = client.bottom - client.top;
}

void ECoreEffectRender::destroyRenderer()
{
	mRenderWindow = NULL;
}

void ECoreEffectRender::startLooping(float fps)
{
	stopLooping();

	if (mRenderThread)
		return;

	mRenderFps = fps;

	mRenderEvent = ::CreateEvent(NULL, FALSE, FALSE, NULL);
	mRenderTimer = ::timeSetEvent((UINT32)(1000.0f / mRenderFps), 0, (LPTIMECALLBACK)mRenderEvent, NULL, TIME_PERIODIC | TIME_CALLBACK_EVENT_SET);

	mRenderLooping = TRUE;
	mRenderThread = CreateThread(NULL, 0x0, _thread_run, this, 0x0, NULL);
}

void ECoreEffectRender::stopLooping()
{
	if (!mRenderThread)
		return;

	mRenderLooping = FALSE;
	WaitForSingleObject(mRenderThread, INFINITE);

	::timeKillEvent(mRenderTimer);
	::CloseHandle(mRenderEvent);
	::CloseHandle(mRenderThread);

	mRenderTimer = NULL;
	mRenderEvent = NULL;
	mRenderThread = NULL;
}


void ECoreEffectRender::startPreview(const char* videoFile, const char* effectFile)
{
	std::string vFile, eFile;
	if (videoFile)
		vFile = videoFile;
	if (effectFile)
		eFile = effectFile;

	std::function<void()> func = [=]()
	{
		this->onStartPreview(vFile.c_str(), eFile.c_str());
	};

	EnterCriticalSection(&mAsyncFuncLock);
	mAsyncFunctions.push_back(func);
	LeaveCriticalSection(&mAsyncFuncLock);
}

void ECoreEffectRender::stopPreview()
{
	std::function<void()> func = [=]()
	{
		this->onStopPreview();
	};

	EnterCriticalSection(&mAsyncFuncLock);
	mAsyncFunctions.push_back(func);
	LeaveCriticalSection(&mAsyncFuncLock);
}

void ECoreEffectRender::previewSizeChange()
{
	RECT client;
	::GetClientRect(mRenderWindow, &client);
	
	mRenderWidth = client.right - client.left;
	mRenderHeight = client.bottom - client.top;

	std::function<void()> func = [=]()
	{
		this->onPreviewSizeChange();
	};

	EnterCriticalSection(&mAsyncFuncLock);
	mAsyncFunctions.push_back(func);
	LeaveCriticalSection(&mAsyncFuncLock);
}

DWORD ECoreEffectRender::_thread_run(LPVOID pParam)
{
	ECoreEffectRender* pThis = (ECoreEffectRender*)pParam;
	return pThis->thread_run();
}

DWORD ECoreEffectRender::thread_run()
{
	onLoopingStart();

	while (mRenderLooping)
	{
		EnterCriticalSection(&mAsyncFuncLock);
		while (!mAsyncFunctions.empty())
		{
			std::function<void()>& call_func = mAsyncFunctions.front();
			call_func();
			mAsyncFunctions.pop_front();
		}
		LeaveCriticalSection(&mAsyncFuncLock);

		WaitForSingleObject(mRenderEvent, 1000L);
		onLoopingFrame();
	}
	onLoopingStop();
	return 0xdead;
}
