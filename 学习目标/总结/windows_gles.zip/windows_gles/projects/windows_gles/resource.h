﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 ecoreeffectdemo.rc 使用
//
#define IDR_MAINFRAME                   110
#define IDD_ECORE_EFFECT_DEMO_DIALOG    121
#define IDD_ECORE_SELECT_API_DIALOG     122
#define IDC_RADIO_SELECT_DIRECT3D11     1000
#define IDC_RADIO_SELECT_OPENGLES30     1001
#define IDC_LIST_EFFECT_LIST            1002
#define IDC_STATIC_EFFECT_PREVIEW       1003
#define IDC_BUTTON_PREVIEW              1004
#define IDC_EDIT_VIDEO_FILE             1005
#define IDC_BUTTON_SELECT_VIDEO         1006
#define IDC_STATIC_RESOLUTION_RATIO     1007
#define IDC_STATIC_VIDEO_FILE           1008
#define IDC_BUTTON_UNLOAD_ENGINE        1009
#define IDC_BUTTON_RELOAD_ENGINE        1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
