#pragma once

#include "ECoreEffectRender.h"

#include <stdio.h>
#include <string>

#include <d3d11_1.h>
#pragma comment(lib, "d3d11.lib")

#include <d3d11shader.h>
#include <d3dcompiler.h>
#pragma comment(lib, "d3dcompiler.lib")

#include <directxmath.h>
#include <directxcolors.h>
#include <dxgidebug.h>

using namespace DirectX;

class ECoreEffectRenderDX11 : public ECoreEffectRender
{
public:
	ECoreEffectRenderDX11();
	virtual ~ECoreEffectRenderDX11();

protected:
	D3D_DRIVER_TYPE mDriverType;
	D3D_FEATURE_LEVEL mFeatureLevel;

	CComPtr<ID3D11Debug> pD3DDebug;

	CComPtr<ID3D11Device> pD3D11Device;
	CComPtr<ID3D11DeviceContext> pD3D11Context;
	CComPtr<IDXGISwapChain> pD3D11SwapChain;

	CComPtr<ID3D11Device1> pD3D11Device1;
	CComPtr<ID3D11DeviceContext1> pD3D11Context1;
	CComPtr<IDXGISwapChain1> pD3D11SwapChain1;

	CComPtr<ID3D11RenderTargetView> pDefaultTargetView;
	CComPtr<ID3D11DepthStencilView> pDefaultDepthView;

public:
	virtual void onLoopingStart();
	virtual void onLoopingFrame();
	virtual void onLoopingStop();

	virtual void onStartPreview(const char* videoFile, const char* effectFile);
	virtual void onStopPreview();

	virtual void onPreviewSizeChange();

private:
	HRESULT init_device(int width, int height);

	HRESULT init_resource();

	uint64_t CreateTextureWithRGBAInThread();
	void createDrawer();
	void destroyDrawer();

	void onRendeFrame();
	void renderPlane(ID3D11ShaderResourceView* textureView);


private:
	std::string mModulePath;

	double mFrameTime = 0.0f;

	ID3D11VertexShader* g_pVertexShader = nullptr;
	ID3D11PixelShader* g_pPixelShader = nullptr;
	ID3D11InputLayout* g_pVertexLayout = nullptr;
	ID3D11Buffer* g_pVertexBuffer = nullptr;
	ID3D11Buffer* g_pIndexBuffer = nullptr;
	ID3D11Buffer* g_pCBNeverChanges = nullptr;
	ID3D11Buffer* g_pCBChangeOnResize = nullptr;
	ID3D11Buffer* g_pCBChangesEveryFrame = nullptr;
	ID3D11SamplerState* g_pSamplerLinear = nullptr;
	ID3D11ShaderResourceView* g_pDataTextureResourceView = nullptr;
	XMMATRIX                            g_World;
	XMMATRIX                            g_View;
	XMMATRIX                            g_Projection;
	XMFLOAT4                            g_vMeshColor;

};

