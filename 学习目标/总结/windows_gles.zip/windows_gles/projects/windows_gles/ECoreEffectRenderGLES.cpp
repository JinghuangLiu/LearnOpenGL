#include "pch.h"
#include "ECoreEffectRenderGLES.h"

#include "stb_image.h"
#include "ECoreUtility.h"

#include "xsdraw/xsprite_draw_texture_mvp_vert.glsl"
#include "xsdraw/xsprite_draw_texture_mvp_frag.glsl"

ECoreEffectRenderGLES::ECoreEffectRenderGLES()
{

}

ECoreEffectRenderGLES::~ECoreEffectRenderGLES()
{
	//ECoreDestroyFunctions();
}

void ECoreEffectRenderGLES::onLoopingStart()
{
	EGLConfig config;
	EGLint majorVersion;
	EGLint minorVersion;

	mEGLDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);
	if (mEGLDisplay == EGL_NO_DISPLAY)
		return;

	// Initialize EGL
	if (!eglInitialize(mEGLDisplay, &majorVersion, &minorVersion))
		return;

	EGLint numConfigs = 0;
	EGLint configAttribs[] =
	{
		   EGL_RED_SIZE,       8,
		   EGL_GREEN_SIZE,     8,
		   EGL_BLUE_SIZE,      8,
		   EGL_ALPHA_SIZE,      EGL_DONT_CARE,
		   EGL_DEPTH_SIZE,      EGL_DONT_CARE,
		   EGL_STENCIL_SIZE,    EGL_DONT_CARE,
		   EGL_SAMPLE_BUFFERS,  0,
		   EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT_KHR,
		EGL_NONE
	};

	// Choose config
	if (!eglChooseConfig(mEGLDisplay, configAttribs, &config, 1, &numConfigs))
		return;

	if (numConfigs < 1)
		return;

	eglBindAPI(EGL_OPENGL_ES_API);

	// Create a surface
	EGLint surfaceAttribs[] =
	{
		EGL_NONE
	};
	mEGLSurface = eglCreateWindowSurface(mEGLDisplay, config, mRenderWindow, surfaceAttribs);
	if (mEGLSurface == EGL_NO_SURFACE)
		return;

	// Create a GL context
	EGLint contextAttribs[] =
	{
		EGL_CONTEXT_CLIENT_VERSION, 3,
		EGL_NONE
	};
	mEGLContext = eglCreateContext(mEGLDisplay, config, EGL_NO_CONTEXT, contextAttribs);
	if (mEGLContext == EGL_NO_CONTEXT)
		return;

	// Make the context current
	if (!eglMakeCurrent(mEGLDisplay, mEGLSurface, mEGLSurface, mEGLContext))
		return;

	createTexture();
	createDrawer();
}

void ECoreEffectRenderGLES::onLoopingFrame()
{
	eglMakeCurrent(mEGLDisplay, mEGLSurface, mEGLSurface, mEGLContext);

	renderFrame();

	eglSwapBuffers(mEGLDisplay, mEGLSurface);
}

void ECoreEffectRenderGLES::onLoopingStop()
{
	destroyDrawer();

	if (mEGLContext != EGL_NO_CONTEXT)
	{
		eglMakeCurrent(mEGLDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
		eglDestroyContext(mEGLDisplay, mEGLContext);
	}

	if (mEGLSurface != EGL_NO_SURFACE)
		eglDestroySurface(mEGLDisplay, mEGLSurface);

	if (mEGLDisplay != EGL_NO_DISPLAY)
		eglTerminate(mEGLDisplay);

	mEGLContext = nullptr;
	mEGLSurface = nullptr;
	mEGLDisplay = nullptr;
}

void ECoreEffectRenderGLES::createTexture()
{
	/////////
	std::string image = "F:/VS2019Projects/windows_gles/test_image.png";

	FILE* imageFile = nullptr;
	fopen_s(&imageFile, image.c_str(), "rb");
	if (imageFile == nullptr)
		return;

	//you must flip the image when send it into ecore engine.
	//stbi_set_flip_vertically_on_load(1);

	int width, height, comp;
	uint8_t* imageData = stbi_load_from_file(imageFile, &width, &height, &comp, 4);
	if (imageData == nullptr)
		return;

	glGenTextures(1, &mImageTexture);
	glBindTexture(GL_TEXTURE_2D, mImageTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, imageData);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	fclose(imageFile);
	stbi_image_free(imageData);
}

void ECoreEffectRenderGLES::createDrawer()
{
	const float* vertexArray = XSUtils::getVertexBufferSix();
	memcpy(mVtxBuf, vertexArray, sizeof(mVtxBuf));

	const float* textureArray = XSUtils::getTexcoodBufferSix();
	memcpy(mTxtBuf, textureArray, sizeof(mTxtBuf));

	mProgram.reset(new XSProgram(xsprite_draw_texture_mvp_vert, xsprite_draw_texture_mvp_frag));
}

void ECoreEffectRenderGLES::destroyDrawer()
{
	onStopPreview();

	if (mImageTexture)
	{
		glDeleteTextures(1, &mImageTexture);
		mImageTexture = 0;
	}
}

void ECoreEffectRenderGLES::renderFrame()
{
	mFrameTime += (1.0f / mRenderFps);

	glViewport(0, 0, mRenderWidth, mRenderHeight);

	glClearColor(0, 0, 0, 1);
	glClearDepthf(1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


	//_projmat.makePerspective(M_PI/3, 1.0f*mRenderWidth/ mRenderHeight, 0.1, 100);
	//_viewmat.makeLookAt(XSVector3(0, 0, 0), XSVector3(0, 0, -1), XSVector3(0, 1, 0));
	//_modelmat.makeTranslate(-0.38, 0.07, 0);

	_projmat.makeIdentity();
	_viewmat.makeIdentity();
	_modelmat.makeIdentity();

	//XSVector4 point1(mVtxBuf[0], mVtxBuf[1], mVtxBuf[2], 1.0f);
	//XSVector4 result1;
	//XSMatrix::multiply(result1, _modelmat, point1);

	//XSVector4 result2;
	//XSMatrix::multiply(result2, _viewmat, result1);

	//XSVector4 result3;
	//XSMatrix::multiply(result3, _projmat, result2);

	mProgram->useProgram();

	int uProject = mProgram->getUniformLocation("u_Project");
	glUniformMatrix4fv(uProject, 1, false, _projmat.m);

	int uView = mProgram->getUniformLocation("u_View");
	glUniformMatrix4fv(uView, 1, false, _viewmat.m);

	int uModel = mProgram->getUniformLocation("u_Model");
	glUniformMatrix4fv(uModel, 1, false, _modelmat.m);

	int posAttrib = mProgram->getAttributeLocation("a_Position");
	int txtAttrib = mProgram->getAttributeLocation("a_texCoord");

	glEnableVertexAttribArray(posAttrib);
	glEnableVertexAttribArray(txtAttrib);

	glVertexAttribPointer(posAttrib, 3, GL_FLOAT, false, 0, mVtxBuf);
	glVertexAttribPointer(txtAttrib, 2, GL_FLOAT, false, 0, mTxtBuf);

	int imgAttrib = mProgram->getUniformLocation("SamplerRGBA");
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, mImageTexture);
	glUniform1i(imgAttrib, 0);

	glDrawArrays(GL_TRIANGLES, 0, 6);


	if (mFrameTime > 20)
	{
		mFrameTime = 0;
		OutputDebugString("Rest frame time to zero .....");
	}
}

void ECoreEffectRenderGLES::onStartPreview(const char* videoFile, const char* effectFile)
{
	onStopPreview();	
}

void ECoreEffectRenderGLES::onStopPreview()
{

}

void ECoreEffectRenderGLES::onPreviewSizeChange()
{

}