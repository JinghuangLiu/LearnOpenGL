#pragma once

class ECoreEffectRender
{
public:
	ECoreEffectRender();
	virtual ~ECoreEffectRender();

protected:
	int mRenderWidth = 64;
	int mRenderHeight = 64;
	float mRenderFps = 25;
	volatile BOOL mRenderLooping = FALSE;
	HWND	mRenderWindow = NULL;
	HANDLE	mRenderThread = NULL;
	UINT32	mRenderTimer = NULL;
	HANDLE	mRenderEvent = NULL;

	std::string mBuiltinPath;

	CRITICAL_SECTION mAsyncFuncLock;
	std::deque<std::function<void()>> mAsyncFunctions;

public:
	virtual void createRenderer(const char* builtin, HWND wind);
	virtual void destroyRenderer();

	virtual void startLooping(float fps);
	virtual void stopLooping();

	virtual void previewSizeChange();

	virtual void startPreview(const char* videoFile, const char* effectFile);
	virtual void stopPreview();

private:
	static DWORD WINAPI _thread_run(LPVOID pParam);
	DWORD thread_run();

protected://be called in thread stack
	virtual void onLoopingStart() = 0;
	virtual void onLoopingFrame() = 0;
	virtual void onLoopingStop() = 0;

	virtual void onStartPreview(const char* videoFile, const char* effectFile) = 0;
	virtual void onStopPreview() = 0;

	virtual void onPreviewSizeChange() = 0;
};

