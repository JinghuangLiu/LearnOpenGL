#pragma once

#include "ECoreEffectRender.h"

#include "EGL/egl.h"
#include "EGL/eglext.h"
#include "EGL/eglplatform.h"

#include "GLES3/gl3.h"
#include "GLES3/gl31.h"
#include "GLES3/gl32.h"
#include "GLES3/gl3platform.h"

#pragma comment(lib, "libEGL.lib")
#pragma comment(lib, "libGLESv2.lib")
#pragma comment(lib, "libMaliEmulator.lib")

#include "xsdraw/XSDrawer.h"
#include "xsdraw/XSDrawerTEX.h"

using namespace xscore;


class ECoreEffectRenderGLES : public ECoreEffectRender
{
public:
	ECoreEffectRenderGLES();
	virtual ~ECoreEffectRenderGLES();

protected:
	EGLDisplay mEGLDisplay = nullptr;
	EGLContext mEGLContext = nullptr;
	EGLSurface mEGLSurface = nullptr;

public:

	virtual void onLoopingStart();
	virtual void onLoopingFrame();
	virtual void onLoopingStop();

	virtual void onStartPreview(const char* videoFile, const char* effectFile);
	virtual void onStopPreview();

	virtual void onPreviewSizeChange();

	double mFrameTime = 0.0f;

	GLuint mImageTexture = 0;
	std::shared_ptr<XSProgram> mProgram;
	float mVtxBuf[18];
	float mTxtBuf[12];

	XSMatrix _projmat;
	XSMatrix _viewmat;
	XSMatrix _modelmat;

private:
	void createTexture();
	void createDrawer();

	void destroyDrawer();
	void renderFrame();
};

