﻿
// ECoreDemoDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "ECoreDemoApp.h"
#include "ECoreDemoDlg.h"
#include "ECoreUtility.h"

#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CECoreDemoDlg 对话框
#include "ECoreEffectRenderDX11.h"
#include "ECoreEffectRenderGLES.h"


CECoreDemoDlg::CECoreDemoDlg(ECoreSelectAPI apiType, CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_ECORE_EFFECT_DEMO_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	mSelectAPI = apiType;
}

void CECoreDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_VIDEO_FILE, mStaticVideoFile);
	DDX_Control(pDX, IDC_EDIT_VIDEO_FILE, mEditVideoFile);
	DDX_Control(pDX, IDC_BUTTON_SELECT_VIDEO, mButtonVideoFile);
	DDX_Control(pDX, IDC_LIST_EFFECT_LIST, mListEffectList);
	DDX_Control(pDX, IDC_STATIC_EFFECT_PREVIEW, mEffectPreview);
	DDX_Control(pDX, IDC_STATIC_RESOLUTION_RATIO, mStaticResolution);
	DDX_Control(pDX, IDC_BUTTON_PREVIEW, mButtonPreview);
	DDX_Control(pDX, IDC_BUTTON_UNLOAD_ENGINE, mButtonUnload);
	DDX_Control(pDX, IDC_BUTTON_RELOAD_ENGINE, mButtonReload);
}

BEGIN_MESSAGE_MAP(CECoreDemoDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_SIZE()
	ON_WM_CLOSE()
	ON_LBN_DBLCLK(IDC_LIST_EFFECT_LIST, &CECoreDemoDlg::OnLbnDblclkListEffectList)
	ON_BN_CLICKED(IDC_BUTTON_PREVIEW, &CECoreDemoDlg::OnBnClickedButtonPreview)
	ON_BN_CLICKED(IDC_BUTTON_UNLOAD_ENGINE, &CECoreDemoDlg::OnBnClickedButtonUnloadEngine)
	ON_BN_CLICKED(IDC_BUTTON_RELOAD_ENGINE, &CECoreDemoDlg::OnBnClickedButtonReloadEngine)
END_MESSAGE_MAP()


// CECoreDemoDlg 消息处理程序

BOOL CECoreDemoDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	OnSizeChange();

	OnInitPath();
	OnInitData();

	loadRenderer();

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CECoreDemoDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CECoreDemoDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CECoreDemoDlg::OnClose()
{
	unloadRenderer();

	CDialogEx::OnClose();
}


void CECoreDemoDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	if (mStaticVideoFile.GetSafeHwnd())
		OnSizeChange();
}

void CECoreDemoDlg::OnInitPath()
{
	HMODULE hModule = ::GetModuleHandle(nullptr);
	TCHAR tmpPath[MAX_PATH];
	::GetModuleFileName(hModule, tmpPath, MAX_PATH);

	std::string rootPath = tmpPath;
	ECoreUtility::stringReplace(rootPath, '\\', '/');

	for (int idx = 0; idx < 7; idx++)
		rootPath = ECoreUtility::findPathParent(rootPath);

	mEffectCoreRoot = rootPath;
}

void CECoreDemoDlg::OnInitData()
{
	std::string assetsRoot = mEffectCoreRoot + "/root";

	EffectItemData item;
	{
		item.name = _T("effect1");
		item.config = assetsRoot + "/effect1/config.json";
		mEffectDatas.push_back(item);
	}

	for (auto& item : mEffectDatas)
	{
		mListEffectList.AddString(item.name.c_str());
	}
}

void CECoreDemoDlg::OnSizeChange()
{
	RECT screen;
	GetClientRect(&screen);
	float scnWidth = screen.right - screen.left;
	float scnHeight = screen.bottom - screen.top;

	RECT rect;

	float dpi = (float)theApp.mDeviceDPI;

#define DPI_SIZE(x) ((x) * dpi)

	//== top line
	float margin = DPI_SIZE(10);
	float top = margin;

	{
		float left = margin;
		float height = DPI_SIZE(20);

		rect.top = top;
		rect.bottom = rect.top + height;
		               
		{
			rect.left = left;
			rect.right = rect.left + DPI_SIZE(70);
			mStaticVideoFile.MoveWindow(&rect);
			left += DPI_SIZE(70);
		}

		{
			float editWidth = scnWidth - left - margin - DPI_SIZE(70);

			rect.left = left;
			rect.right = rect.left + editWidth;
			mEditVideoFile.MoveWindow(&rect);
			left += editWidth;
		}

		{
			rect.left = left;
			rect.right = rect.left + DPI_SIZE(70);
			mButtonVideoFile.MoveWindow(&rect);
			left += DPI_SIZE(70);
		}

		top += height;
		top += margin;
	}
	
	float listWidth = DPI_SIZE(200);
	float bottomButtonHeight = DPI_SIZE(40);

	{
		float left = margin;
		float height = scnHeight - top - 2 * margin - bottomButtonHeight;

		rect.top = top;
		rect.bottom = rect.top + height;

		{
			rect.left = left;
			rect.right = rect.left + listWidth;
			mListEffectList.MoveWindow(&rect);
			left += listWidth;
		}

		{
			float previewWidth = scnWidth - left - margin;

			rect.left = left;
			rect.right = rect.left + previewWidth;
			mEffectPreview.MoveWindow(&rect);
			mEffectPreview.InvalidateRect(&rect);
			left += previewWidth;
		}

		top += height;
		top += margin;
	}

	{
		float left = margin;
		float height = bottomButtonHeight;

		rect.top = top;
		rect.bottom = rect.top + height;

		{
			rect.left = left;
			rect.right = rect.left + DPI_SIZE(100);
			mButtonPreview.MoveWindow(&rect);
			left += DPI_SIZE(100);
		}

		{
			rect.left = listWidth + margin;
			rect.right = rect.left + DPI_SIZE(100);
			mStaticResolution.MoveWindow(&rect);
			left += DPI_SIZE(100);
		}

		float right = screen.right - margin;

		{
			rect.right = right;
			rect.left = rect.right - DPI_SIZE(100);
			mButtonReload.MoveWindow(&rect);
			right -= DPI_SIZE(100);
		}

		right -= margin;

		{
			rect.right = right;
			rect.left = rect.right - DPI_SIZE(100);
			mButtonUnload.MoveWindow(&rect);
			right -= DPI_SIZE(100);
		}
	}
	
	RECT previewRect;
	mEffectPreview.GetClientRect(&previewRect);
	TCHAR textbuf[128];
	_stprintf_s(textbuf, _T("%dx%d"), previewRect.right - previewRect.left, previewRect.bottom - previewRect.top);
	mStaticResolution.SetWindowText(textbuf);

	if (mEffectRenderer)
		mEffectRenderer->previewSizeChange();

#undef DPI_SIZE
}

void CECoreDemoDlg::loadRenderer()
{
	unloadRenderer();

	if (mSelectAPI == ECoreSelectAPI::ECORE_SELECT_API_DIRECT3D11)
		mEffectRenderer = new ECoreEffectRenderDX11();
	else if (mSelectAPI == ECoreSelectAPI::ECORE_SELECT_API_OPENGLES30)
		mEffectRenderer = new ECoreEffectRenderGLES();

	std::string builtinRoot = mEffectCoreRoot + "/Resource/ecore-effect-sdk/assets/EffectCore/Builtin";

	mEffectRenderer->createRenderer(builtinRoot.c_str(), mEffectPreview.GetSafeHwnd());
	mEffectRenderer->startLooping(25);
}

void CECoreDemoDlg::unloadRenderer()
{
	if (mEffectRenderer)
	{
		mEffectRenderer->stopLooping();
		mEffectRenderer->destroyRenderer();

		delete mEffectRenderer;
		mEffectRenderer = nullptr;
	}
}

void CECoreDemoDlg::OnBnClickedButtonPreview()
{
	int selidx = mListEffectList.GetCurSel();
	if (selidx < 0 || selidx >= mEffectDatas.size())
		return;

	EffectItemData& effectItem = mEffectDatas[selidx];

	CString videoPath;
	mEditVideoFile.GetWindowText(videoPath);

	const char* videoFile = nullptr;
	if (videoPath.GetLength() > 0)
		videoFile = videoPath.GetString();

	mEffectRenderer->startPreview(videoFile, effectItem.config.c_str());
}


void CECoreDemoDlg::OnLbnDblclkListEffectList()
{
	OnBnClickedButtonPreview();
}


void CECoreDemoDlg::OnBnClickedButtonUnloadEngine()
{
	unloadRenderer();
}


void CECoreDemoDlg::OnBnClickedButtonReloadEngine()
{
	loadRenderer();
}
