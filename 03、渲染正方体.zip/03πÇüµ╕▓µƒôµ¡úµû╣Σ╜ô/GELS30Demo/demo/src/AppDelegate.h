//
//  AppDelegate.h
//  ECoreEngineDemo
//
//  Created by migu on 2022/2/7.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UINavigationController* rootvc;

@end

