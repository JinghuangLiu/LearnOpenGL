//
//  LYGLViewController.h
//  LearnOpenGLES
//
//  Created by loyinglin on 16/3/16.
//  Copyright © 2016年 loyinglin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYGLViewController : UIViewController

@end
