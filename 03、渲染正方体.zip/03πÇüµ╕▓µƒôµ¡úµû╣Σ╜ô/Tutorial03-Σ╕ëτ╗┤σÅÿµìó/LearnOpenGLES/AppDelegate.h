//
//  AppDelegate.h
//  LearnOpenGLES
//
//  Created by loyinglin on 16/3/11.
//  Copyright © 2016年 loyinglin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

