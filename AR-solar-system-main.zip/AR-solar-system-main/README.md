![ARSolarPlay](ARSolarPlay/Asset/cover.png)

## ARSolarPlay

- This project is used to demonstrate the motion of the solar system, we can observe each planet or solar system from any angle and the details of the trajectory.
- We use ARKit technology to achieve it, I'm surprised at its effect.


## Requirements

- iOS 11.0+
- Xcode 9.0+
- iPhone 6s+


 



