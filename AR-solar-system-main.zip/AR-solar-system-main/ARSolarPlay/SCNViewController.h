//
//  SCNViewController.h
//  ARPlayDemo
//
//  Created by alexyang on 2017/7/11.
//  Copyright © 2017年 alexyang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCNViewController : UIViewController
@property(nonatomic, assign) BOOL isCardBoard;

@end
